from flask import Flask, request, jsonify, Response,send_file
import pickle
import os
import io
from pydantic import BaseModel
import json
import numpy as np
import matplotlib.pyplot as plt
import pickle
import shap
import pandas as pd
import gc
from waitress import serve
from multiprocessing import Process
from flask import abort
import time
import consts
from recorder import update_job_status,get_num_jobs,\
	get_num_processing_jobs,was_processed,get_job_status

app = Flask(__name__)

print("Lendo dados de treinamento para Explicabilidade...")
X_train = pd.read_csv('X_train.csv')

print("Carregando Modelo Treinado...")
modelo = pickle.load(open('modengajamais.pkl','rb'))

print("Gerando Array de Explicabilidade...")
explainer = shap.TreeExplainer(modelo, X_train, model_output='probability')
print("Array gerado!")
plt.switch_backend('agg')
gc.enable()

if not os.path.isdir(consts.PASTA_PADRAO_IMG):
	os.makedirs(consts.PASTA_PADRAO_IMG, exist_ok=True)


class Data(BaseModel):
	cod_tp_assunto: str
	colaborador: str

##############################################################
def salvarfigura(nome,formato,plt,dpi=None):
	plt.savefig(consts.PASTA_PADRAO_IMG+"/"+nome+"."+formato,bbox_inches="tight",dpi=dpi,format=formato)

def recuperafigura(nome,formato):
	result = os.open(consts.PASTA_PADRAO_IMG + "/" + nome + "." + formato, os.O_RDONLY)
	return result


def processasummary(dadosreq,job_id,formato):
	update_job_status(job_id, consts.WAITING_STATUS)

	# start to process the bidding
	while get_num_jobs(consts.RUNNING_STATUS) > consts.MAX_NUM_CONCURRENT_RUNNING_JOBS:
		# it is possible the later received jobs will jump out of this while
		# loop first than the earlier received jobs
		# Queue can be a solution to this, but then we need a background worker to
		# pick up the jobs in queue
		time.sleep(consts.SLEEPING_SECONDS)


	# there is extream case that two jobs are freed out from while loop
	# at the same instance

	# there is available worker to run this job
	# lock this worker for running this job
	update_job_status(job_id, consts.RUNNING_STATUS)
	try:
		# simulate time expensive task
		X_test = pd.DataFrame.from_dict(dadosreq)
		# print(X_test)
		check_additivity = True
		shap_values = explainer(X_test, check_additivity=check_additivity)
		shap.summary_plot(shap_values, X_test, plot_type='violin', show=False, plot_size=[10.5, 7])
		salvarfigura(job_id, formato, plt)
		del X_test, shap_values, dadosreq
		plt.clf()
		gc.collect()
		# finish job running, unlock the worker
		update_job_status(job_id, consts.COMPLETED_STATUS)
	except:
		update_job_status(job_id, consts.FAILED_STATUS)
		abort(403)

def orderdict(array,tpop=1):
	if tpop == 1:
		vnovoarray = []
		for item in array:
			vdictorder = dict()
			for col in X_train.columns:
				vdictorder[col] = item[col]
			vnovoarray.append(vdictorder)
		return vnovoarray
	else:
		vdictorder = dict()
		for col in X_train.columns:
			vdictorder[col] = array[col]
		return vdictorder
##############################################################

@app.route('/')
def verifica_api_online():
	print("verifica_api_online")
	print("========================")
	return "API ONLINE 1.0",200

@app.route('/predevasao',methods=['POST'])
def predevasao():
	dados = request.get_json(force=True)
	dados = orderdict(dados)
	print(dados)
	resposta = []
	try:
		for data_dict in dados:
			convertidos = np.array([list(data_dict.values())])
			#print(convertidos)
			#print(convertidos.reshape(1, -1))
			predicao = modelo.predict(convertidos)
			pred_proba = modelo.predict_proba(convertidos)
			resposta.append({"prediction": float(predicao[0]),
							 "proba_0": float(pred_proba[0][0]),
							 "proba_1": float(pred_proba[0][1])})
		# return {"retorno":to_predict}
		#print(resposta)
		print("========================")
		return json.dumps(resposta)
	except Exception as inst:
		print('Erro Encontrado:')
		print(inst)
		print("========================")
		return json.dumps([{"prediction": float(0)}])


@app.route('/summarypng/<job_id>',methods=['POST'])
def summary_png(job_id):
	#convertidos = np.array([list(data_dict.values()) for data_dict in X_test])
	# check not too many processing jobs
	number_process_running = get_num_processing_jobs()
	if number_process_running >= consts.MAX_NUM_CONCURRENT_PROCESSING_JOBS:
		return json.dumps([{"job": job_id,
							"status": "Bad request, job_id foi recusada, muitos jobs estao sendo executados: %s" %
									  (number_process_running)}]), 401

	dadosreq = request.get_json(force=True)
	dadosreq = orderdict(dadosreq)
	if dadosreq is None:
		return json.dumps([{"job": job_id,
							"status": "Bad request, requisicao sem informacoes no corpo na mensagem"}]),401

	# check if the job was already processed
	if was_processed(job_id):
		return json.dumps([{"job": job_id,
							"status": "Bad request, job_id ja foi recebida, seu status atual e: %s" %
									get_job_status(job_id)}]),401

	bidding_cb = Process(target=processasummary, args=(dadosreq, job_id,'png'))
	bidding_cb.start()

	return json.dumps([{"job": job_id,"status": "recebida"}])


@app.route('/plotforcewall.png',methods=['POST'])
def plotforcewallft_png():
	dadosreq = request.get_json(force=True)
	dadosreq = orderdict(dadosreq)
	X_test = pd.DataFrame.from_dict(dadosreq)
	check_additivity = True
	shap_values = explainer(X_test, check_additivity=check_additivity)
	# print(shap_values[0].values)
	# print(np.sum(shap_values[0].values)*2)
	shap.plots.waterfall(shap_values[0], show=False,max_display=15)
	output = io.BytesIO()
	plt.savefig(output, bbox_inches="tight", format="png")
	#FigureCanvas(fig).print_png(output)
	print('plotforcewall gerado!', dadosreq)
	print("========================")
	del X_test, shap_values, dadosreq
	plt.clf()
	gc.collect()
	return Response(output.getvalue(), mimetype='image/png')


@app.route('/plotforce.png',methods=['POST'])
def plotforceft_png():
	dadosreq = request.get_json(force=True)
	dadosreq = orderdict(dadosreq)
	X_test = pd.DataFrame.from_dict(dadosreq)
	check_additivity = True
	shap_values = explainer(X_test, check_additivity=check_additivity)
	output = io.BytesIO()
	shap.plots.force(shap_values[0],matplotlib=True,
					 show=False,text_rotation=12).savefig(output, bbox_inches="tight",format="png")
#	FigureCanvas(fig).print_png(output)
	print('plotforce gerado!', dadosreq)
	print("========================")
	del X_test, shap_values, dadosreq
	plt.clf()
	gc.collect()
	return Response(output.getvalue(), mimetype='image/png')

@app.route("/status/<job_id>", methods=['GET'])
def status(job_id):
	job_status = get_job_status(job_id)
	return json.dumps([{"job": job_id, "status": job_status}]),200
	# return job_status, 200

@app.route("/recuperasummary/<job_id>", methods=['GET'])
def recuperasummary(job_id):
	job_status = get_job_status(job_id)
	if job_status == consts.COMPLETED_STATUS:
		#output = recuperafigura(job_id, 'png')
		#os.remove(consts.PASTA_PADRAO_IMG+'/'+job_id+'.png')
		try:
			return send_file(consts.PASTA_PADRAO_IMG+'/'+job_id+'.png', mimetype='image/png'),200
		except:
			abort(404)
	else:
		abort(404)

@app.route("/apagasummary/<job_id>", methods=['DELETE'])
def apagasummary(job_id):
	job_status = get_job_status(job_id)
	if job_status == consts.COMPLETED_STATUS:
		try:
			os.remove(consts.PASTA_PADRAO_IMG+'/'+job_id+'.png')
			return json.dumps([{"job": job_id, "status": "deteled"}]),200
		except:
			abort(404)
	else:
		abort(404)


if __name__ == "__main__":
	# port = int(os.environ.get("PORT",5000))
	# app.run(host='0.0.0.0',port=port,threaded = True)
	serve(app, host='0.0.0.0', port=5000,threads=8)
	# http_server = WSGIServer(('', 5000), app)
	# http_server.serve_forever()

